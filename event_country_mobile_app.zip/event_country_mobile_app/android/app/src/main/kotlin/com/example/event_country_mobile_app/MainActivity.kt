package com.example.event_country_mobile_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
